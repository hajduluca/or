package polenapeter;

import java.util.Objects;

public class Candidate {

    private CandidateName name;
    private int electors;
    private long population;


    public Candidate(CandidateName name) {
        this.name = name;
        this.electors = 0;
        this.population = 0;
    }

    public CandidateName getName() {
        return name;
    }

    public int getElectors() {
        return electors;
    }

    public long getPopulation() {
        return population;
    }

    public void addElectors(int electors){
        this.electors += electors;
    }

    public void addPopulation(long population){
        this.population += population;
    }

    public void resetResults(){
        this.electors = 0;
        this.population = 0;
    }

    @Override
    public String toString() {
        return "Candidate{" +
                "name=" + name +
                ", electors=" + electors +
                ", population=" + population +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Candidate candidate = (Candidate) o;
        return electors == candidate.electors &&
                population == candidate.population &&
                name == candidate.name;
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, electors, population);
    }
}
