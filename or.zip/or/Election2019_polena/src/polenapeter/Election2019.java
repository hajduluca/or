package polenapeter;

import java.io.BufferedReader;
import java.io.FileReader;
import java.net.ServerSocket;
import java.util.HashMap;
import java.util.Map;

import static polenapeter.CandidateName.A;
import static polenapeter.CandidateName.B;

public class Election2019 {

    private static Map<String, ElectorsPopState> electorsPopStateMap = new HashMap<>();
    private static Candidate candidateA = new Candidate(A);
    private static Candidate candidateB = new Candidate(B);
    private static long defaultDifference = 1000000;


    public static void main(String[] args) throws Exception {
        int PORT = 2019;

        try(BufferedReader electorsFile = new BufferedReader(new FileReader("electors.txt"))){
            electorsFile.lines().forEach(line -> {
                int electors = Integer.parseInt(line.split("\t")[0]);
                long population = Long.parseLong(line.split("\t")[1]);
                String state = line.split("\t")[2];
                electorsPopStateMap.put(state, new ElectorsPopState(electors, population, state));
            });
        }

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {
                ClientConnection clientConnection = new ClientConnection(serverSocket);
                processCommand(clientConnection);
                Thread.sleep(3000);
                clientConnection.close();
            }
        }
    }

    public static void processCommand(ClientConnection clientConnection) throws Exception {
        String input = clientConnection.getScanner().nextLine();
        String command = input.split(" ")[0];

        switch(command){
            case "A": {
                String state = input.split(" ")[1];
                candidateA.addElectors(electorsPopStateMap.get(state).getElectors());
                candidateA.addPopulation(electorsPopStateMap.get(state).getPopulation());
                returnPartialResult(clientConnection);
                break;
            }
            case "B": {
                String state = input.split(" ")[1];
                candidateB.addElectors(electorsPopStateMap.get(state).getElectors());
                candidateB.addPopulation(electorsPopStateMap.get(state).getPopulation());
                returnPartialResult(clientConnection);
                break;
            }
            case "end": {
                long difference = defaultDifference;
                if(input.split(" ").length == 2){
                    difference = Long.parseLong(input.split(" ")[1]);
                }
                getResult(clientConnection, candidateA, candidateB, difference);
                break;
            }
            default: {
                clientConnection.getPrintWriter().println("INVALID INPUT");
                break;
            }
        }
    }

    private static void returnPartialResult(ClientConnection clientConnection) throws Exception {
        clientConnection.getPrintWriter().println("[A] Electors: " + candidateA.getElectors() + " Votes: " + candidateA.getPopulation());
        clientConnection.getPrintWriter().println("[B] Electors: " + candidateB.getElectors() + " Votes: " + candidateB.getPopulation());
        clientConnection.getPrintWriter().flush();
    }

    public static void getResult(ClientConnection clientConnection,
                                 Candidate candidateA,
                                 Candidate candidateB,
                                 long difference) throws Exception {

        if(candidateA.getElectors() > candidateB.getElectors()
                && candidateA.getPopulation() > candidateB.getPopulation()){

            clientConnection.getPrintWriter().println("A won the election. Electors: " + candidateA.getElectors() + " Votes: " + candidateA.getPopulation());
            clientConnection.getPrintWriter().flush();
        }

        if(candidateA.getElectors() < candidateB.getElectors()
                && candidateA.getPopulation() < candidateB.getPopulation()){

            clientConnection.getPrintWriter().println("B won the election. Electors: " + candidateB.getElectors() + " Votes: " + candidateB.getPopulation());
            clientConnection.getPrintWriter().flush();
        }

        if(candidateA.getElectors() > candidateB.getElectors()
                && candidateA.getPopulation() < candidateB.getPopulation()
                && Math.abs(candidateB.getPopulation() - candidateA.getPopulation()) >= difference){

            clientConnection.getPrintWriter().println("A won more electors, but B got more voters. Restarting election.");
            clientConnection.getPrintWriter().flush();
        }

        if(candidateA.getElectors() < candidateB.getElectors()
                && candidateA.getPopulation() > candidateB.getPopulation()
                && Math.abs(candidateA.getPopulation() - candidateB.getPopulation()) >= difference){

            clientConnection.getPrintWriter().println("B won more electors, but A got more voters. Restarting election.");
            clientConnection.getPrintWriter().flush();
        }

        if(candidateA.getElectors() == candidateB.getElectors()){

            clientConnection.getPrintWriter().println("A and B got the same number of electors. Restarting election.");
            clientConnection.getPrintWriter().flush();
        }

        candidateA.resetResults();
        candidateB.resetResults();
    }
}
