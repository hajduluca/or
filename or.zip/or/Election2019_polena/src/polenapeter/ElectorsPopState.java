package polenapeter;

import java.util.Objects;

public class ElectorsPopState {

    private int electors;
    private long population;
    private String state;

    public ElectorsPopState(int electors, long population, String state){
        this.electors = electors;
        this.population = population;
        this.state = state;
    }

    public int getElectors(){
        return electors;
    }

    public long getPopulation(){
        return population;
    }

    public String getState(){
        return state;
    }

    @Override
    public String toString() {
        return "ElectorsPopState{" +
                "electors=" + electors +
                ", population=" + population +
                ", state='" + state + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ElectorsPopState that = (ElectorsPopState) o;
        return electors == that.electors &&
                population == that.population &&
                Objects.equals(state, that.state);
    }

    @Override
    public int hashCode() {
        return Objects.hash(electors, population, state);
    }
}
