package polenapeter;

public enum CandidateName {
    A, B
}
