package polenapeter;


import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class ClientConnection implements AutoCloseable {

    private Socket socket;
    private Scanner scanner;
    private PrintWriter printWriter;

    ClientConnection(ServerSocket ss) throws Exception {
        this.socket = ss.accept();
        this.scanner = new Scanner(socket.getInputStream());
        this.printWriter = new PrintWriter(socket.getOutputStream());
    }

    public Socket getSocket(){
        return this.socket;
    }

    public Scanner getScanner(){
        return this.scanner;
    }

    public PrintWriter getPrintWriter(){
        return this.printWriter;
    }

    @Override
    public void close() throws Exception {
        if (socket == null) return;
        socket.close();
    }
}
