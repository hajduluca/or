import java.io.*;
import java.util.*;
import java.net.Socket;
import java.net.ServerSocket;

public class Seeder {
	
	private static final int TRACKER_PORT = 55555;
	private static final int SERVER_PORT = 50001;
	private Leecher leecher;
	private ServerSocket server;
	private static Socket tracker;
	private static BufferedReader br;
	private static PrintWriter pw;
	private static Scanner sc;
	public 	static Map<String, String> files = new HashMap<String, String>();

	public static void main(String[] args) throws IOException {
		if (args.length == 0) {
			System.out.println("Kotelezo a parancssori argumentum!");
			System.exit(0);
		}
		tracker = new Socket("localhost", TRACKER_PORT);
		br = new BufferedReader(new InputStreamReader(tracker.getInputStream()));
		pw = new PrintWriter(tracker.getOutputStream());
		sc = new Scanner(System.in);
		
		sendMessage("seed");
		String arguments="";
		for(int i=0; i<args.length;i++){
			arguments+=args[i]+" ";
		}
		sendMessage(arguments);
		
		for(int i=1;i<args.length;i+=2){
			files.put(args[i], args[i+1]);
		}
		
		try {
			Seeder seeder = new Seeder();
			seeder.start();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	static void sendMessage(String message) {
		pw.println(message);
		pw.flush();
	}
	
	private Seeder() throws IOException {
		server = new ServerSocket(SERVER_PORT);
	}
	
	void start() throws IOException {
		System.out.println("Leecherre varunk!");
		try{
			Socket s = server.accept();
			BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			PrintWriter pw = new PrintWriter(s.getOutputStream());
			
			leecher = new Leecher(s, br, pw);	
			
			System.out.println("Egy leecher csatlakozott.");
			handleLeechers();	
		} catch (IOException e) {
			System.out.println("A leecher lecsatlakozott!\n");
			start();
		}
	}
	
	private void handleLeechers() throws IOException {
		System.out.println("Kezdodhet a torrentezes!\n");
		while(leecher.isConnected()) {
				String input = leecher.reader.readLine();
				leecher.sendMessage(files.get(input));
		}
	}

	class Leecher {
		public Socket leecher;
		public BufferedReader reader;
		public PrintWriter writer;
		public String name = "";
		
		Leecher(Socket s, BufferedReader br, PrintWriter pw) {
			this.leecher = s;
			this.reader = br;
			this.writer = pw;
		}
		
		boolean isConnected(){
			return this.leecher.isConnected();
		}
		
		void sendMessage(String message) {
			writer.println(message);
			writer.flush();
		}
	}
}