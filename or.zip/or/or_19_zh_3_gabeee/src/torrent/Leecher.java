/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package torrent;

import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;

/**
 *
 * @author igl9qc
 */
public class Leecher extends Thread{
    
    Queue<String> list;
    
    public Leecher() {
        list = new LinkedList<>();
    }
    
    public void addRequest(String file) {
        synchronized(list) {
            list.add(file);
        }
    }
    
    public void run() {
        while(true) {
            synchronized(list) {
                while(!list.isEmpty()) {
                    String cur = list.poll();
                    try {
                        Socket tracker = new Socket("localhost",55555);

                        PrintWriter pw = new PrintWriter(tracker.getOutputStream());
                        pw.println("leech");
                        pw.println(cur);
                        pw.flush();

                        Scanner sc = new Scanner(tracker.getInputStream());
                        Integer port = Integer.parseInt(sc.nextLine());

                        tracker.close();

                        Socket seeder = new Socket("localhost",port);
                        sc = new Scanner(seeder.getInputStream());
                        pw = new PrintWriter(seeder.getOutputStream());

                        pw.println(cur);
                        pw.flush();

                        String file = sc.nextLine();
                        System.out.println("Got file: " + file);

                        seeder.close();

                    } catch(Exception e) {
                        System.err.println(e);
                    }
                }
            }
        }
        
    }
    
    public static void main(String[] args) {
        String file = args[0];

        Leecher leecher = new Leecher();
        leecher.addRequest(file);
        leecher.start();
    }
}
