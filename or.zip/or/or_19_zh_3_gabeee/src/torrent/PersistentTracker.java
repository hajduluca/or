/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package torrent;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author igl9qc
 */
public class PersistentTracker extends Tracker{
    public PersistentTracker() throws RemoteException {
        super();
        
    }
    
    public Connection con;
    
    @Override
    public void start() {
        String user = "test";
        String password = "1234";
        String host ="jdbc:sqlite:target/sqlite_test.db";
        
        try {
            Class.forName("org.sqlite.JDBC");
            con = DriverManager.getConnection(host, user, password);
            //locations(fileId VARCHAR(80), peerPort INT)
            createTable("locations", "fileId varchar(80)", "peerPort INT");
            
            //query("insert into users (username, password) values (?, ?);", "test", "1234");
            //System.out.println(select("select * from users;").get(0)[1]);
        } catch (Exception e) {
                System.err.println(e);
        }
        
        super.start();
    }
    
    public void storeFileId(String fileId, Integer port) {
        query("insert into locations (fileId, peerPort) values (?, ?);",fileId,port.toString());
    }
    
    public Integer lookupPeerPort(String fileId) {
        return (Integer)select("select * from locations where fileId=?;",fileId).get(0)[1];
    }
    
    public void createTable(String name, String ... cols) {
        try {
            Statement stat = con.createStatement();
            stat.execute("create table if not exists " + name + " (" + String.join(", ", cols) + ");");
            stat.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
    public void query(String sql, String ... args) {
        try {
            PreparedStatement stat = con.prepareStatement(sql);

            for (int i = 0; i < args.length; i++) {
                stat.setString(i+1,args[i]);
            }
            stat.execute();
            stat.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Object[]> select(String sql, String ... args) {
        try {
            PreparedStatement stat = con.prepareStatement(sql);

            for (int i = 0; i < args.length; i++) {
                stat.setString(i+1,args[i]);
            }
            ResultSet result = stat.executeQuery();
            int cols = result.getMetaData().getColumnCount();
            List<Object[]> t = new LinkedList();
            while (result.next()) {
                Object[] ct = new Object[cols];
                for (int i = 0; i < cols; i++) {
                    ct[i] = result.getObject(i+1);
                }
                t.add(ct);
            }
            stat.close();

            return t;

        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
    }
    
    public static void main(String[] args) throws Exception {
        new PersistentTracker().start();
    }
}
