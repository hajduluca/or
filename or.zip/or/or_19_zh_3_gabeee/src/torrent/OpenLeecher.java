/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package torrent;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Collection;

/**
 *
 * @author igl9qc
 */
public class OpenLeecher {
    public static void main(String[] args) throws Exception{
        if(args.length > 0) {
            Leecher.main(args);
        } else {
            Registry registry = LocateRegistry.getRegistry();
            IOpenTracker tracker = (IOpenTracker)registry.lookup("Best tracker");
            Collection<String> t = tracker.fetchFileList();
            for(String s : t) {
                System.out.println(s);
            }            
        }
    }
}
