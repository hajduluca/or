/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package torrent;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Collection;
import java.util.HashSet;

/**
 *
 * @author igl9qc
 */
public class OpenTracker extends Tracker implements IOpenTracker {
    
    
    public OpenTracker() throws RemoteException {
        super();
    }
    public static void main(String[] args) {
        
        try {
            OpenTracker t = new OpenTracker();
            Registry registry = LocateRegistry.getRegistry();
            registry.rebind("Best tracker",t);
            t.start();
        } catch(RemoteException e) {
            System.err.println(e);
        }
        
        
    }

    @Override
    public Collection<String> fetchFileList() throws RemoteException {
        HashSet set = new HashSet();
        track.keySet().forEach(x -> set.add(x));
        return set;
    }
}
