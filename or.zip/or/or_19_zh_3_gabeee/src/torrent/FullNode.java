/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package torrent;

import java.util.Scanner;

/**
 *
 * @author igl9qc
 */
public class FullNode {
    public static void main(String[] args) {
        Integer port = Integer.parseInt(args[0]);

        Seeder seeder = new Seeder(port);
        
        for (int i = 1; i < args.length; i+=2) {
            seeder.add(args[i],args[i+1]);
        }
        
        seeder.start();
        
        Leecher leecher = new Leecher();
        leecher.start();
        
        Scanner sc = new Scanner(System.in);
        String line;
        while(sc.hasNextLine()) {
            line = sc.nextLine();
            leecher.addRequest(line);
        }
    }
}
