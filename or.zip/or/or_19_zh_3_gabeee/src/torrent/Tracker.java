package torrent;

import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Scanner;
import java.util.Stack;


/**
 * Handler
 */
public class Tracker extends UnicastRemoteObject{

    public final int serverPort = 55555;
    public ServerSocket server;

    public Map<String,Integer> track;
    public static Tracker tracker;

    public Tracker() throws RemoteException{
        try {
            this.server = new ServerSocket(serverPort);
        } catch (Exception e) {
            System.err.println(e);
        }
        track = new HashMap<>();
        tracker = this;
    }

    public void start() {
        
        while(true) {
            try {
                Socket socket = server.accept();
                System.out.println("Client connected: " + socket.getInetAddress());
                Scanner sc = new Scanner(socket.getInputStream());
                PrintWriter pw = new PrintWriter(socket.getOutputStream());
                
                String cmd = sc.nextLine();
                String line;
                Integer port;
                switch(cmd) {
                    case "leech":
                        line = sc.nextLine();
                        port = lookupPeerPort(line);
                        pw.println(port);
                        pw.flush();
                        System.out.println("Leech complete");
                        break;
                    case "seed":
                        line = sc.nextLine();
                        port = Integer.parseInt(line);
                        while(sc.hasNextLine()) {
                            line = sc.nextLine();
                            System.out.println("Getting seeder data: " + line);
                            storeFileId(line,port);
                        }
                        System.out.println("Seed complete");
                        break;
                }
                
                socket.close();
            } catch(Exception e) {
                System.err.println(e);
            }
        }
    }
    
    public void storeFileId(String fileId, Integer port) {
        track.put(fileId, port);
    }
    
    public Integer lookupPeerPort(String fileId) {
        return track.get(fileId);
    }
    
    public static void main(String[] args) throws Exception {
        Tracker tracker = new Tracker();
        tracker.start();
    }
}