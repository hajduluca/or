/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package torrent;

import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

/**
 *
 * @author igl9qc
 */
public class Seeder extends Thread {
    
    public Map<String,String> files;
    public ServerSocket server;
    public Integer port;
    
    public Seeder(Integer port) {
        files = new HashMap<>();
        this.port = port;
    }
    
    public void add(String name, String file) {
        files.put(name, file);
    }
    
    public void run() {
        
        try {
            Socket tracker = new Socket("localhost",55555);
            
            PrintWriter pw = new PrintWriter(tracker.getOutputStream());
            pw.println("seed");
            pw.println(port);
            for(String s : files.keySet()) {
                pw.println(s);
            }
            pw.flush();
            
            tracker.close();
            
            server = new ServerSocket(port);
            
        } catch(Exception e) {
            System.err.println(e);
        }
        
        while(true) {
            try {
                Socket socket = server.accept();
                Scanner sc = new Scanner(socket.getInputStream());
                PrintWriter pw = new PrintWriter(socket.getOutputStream());
                
                String name = sc.nextLine();
                String file = files.get(name);
                pw.println(file);
                pw.flush();
                
            } catch (Exception e) {
                //System.err.println(e);
            }
        }
    }
    
    public static void main(String[] args) {
        
        
        Integer port = Integer.parseInt(args[0]);

        Seeder seeder = new Seeder(port);
        
        for (int i = 1; i < args.length; i+=2) {
            seeder.add(args[i],args[i+1]);
        }
        
        seeder.start();
    }
}
