import java.net.ServerSocket;
import java.net.Socket;
import java.io.*;
import java.util.*;

public class Auction {
	private final int SERVER_PORT = 2121;
	private Client client;
	private ServerSocket server;
	private boolean clientDisconnected = false;
	public ArrayList<Item> items = new ArrayList<>();
	
	public static void main(String[] args) {
		try {
			Auction startServer = new Auction();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private Auction() throws IOException {
		server = new ServerSocket(SERVER_PORT);
		newAuction();
	}
	private void newAuction() throws IOException {
		clientDisconnected = false;
		System.out.println("Kliensre varunk!");
		try{
			Socket s = server.accept();
			BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			PrintWriter pw = new PrintWriter(s.getOutputStream());
			
			client = new Client(s, br, pw);	
			
			String name = client.reader.readLine();
			client.name = name;
			System.out.println(name + " csatlakozott az aukciohoz.");
			startAuction();	
		} catch (IOException e) {
			System.out.println("Az ugyfel lecsatlakozott!\n");
			newAuction();
		}
			
	}

	private void startAuction() throws IOException {
		System.out.println("Kezdodhet a licit!\n");
		while(client.isConnected()) {
				String str = client.reader.readLine();
				String[] input = str.split("\\s+");
				
				switch (input[0]) {
					case "put":   	items.add(new Item(input[1], client.name));
									break;
									
					case "list": 	client.sendMessage(String.valueOf(items.size()));
									for(int i=0;i<items.size();i++){
										client.sendMessage(items.get(i).name+" "+items.get(i).price+" "+items.get(i).winner);
									}
										client.sendMessage("stop");
									break;
									
					case "bid": 	int i=0;
									boolean megvan = false;
									while(!megvan){
										if(items.get(i).name.equals(input[1])){
											megvan=true;
											items.get(i).price += 1;
											items.get(i).winner = client.name;											
										}
										i++;
									}
									break;
				}
		}
	}

	class Item{
		public String name;
		public String winner;
		public int price;
		
		Item(String name, String winner){
			this.name=name;
			this.winner=winner;
			this.price=0;
		}		
	}
	
	class Client {
		public Socket client;
		public BufferedReader reader;
		public PrintWriter writer;
		public String name = "";
		
		Client(Socket s, BufferedReader br, PrintWriter pw) {
			this.client = s;
			this.reader = br;
			this.writer = pw;
		}
		
		boolean isConnected(){
			return this.client.isConnected();
		}
		
		void sendMessage(String message) {
			writer.println(message);
			writer.flush();
		}
	}
}