import java.io.*;
import java.util.*;
import java.net.Socket;

public class AuctionClient {
	
	private static final int SERVER_PORT = 2121;
	private static Socket server;
	private static BufferedReader br;
	private static PrintWriter pw;
	private static Scanner sc;

	public static void main(String[] args) throws IOException {
		if (args.length != 1) {
			System.out.println("Kotelezo a nev megadasa!");
			System.exit(0);
		}
		server = new Socket("localhost", SERVER_PORT);
		br = new BufferedReader(new InputStreamReader(server.getInputStream()));
		pw = new PrintWriter(server.getOutputStream());
		sc = new Scanner(System.in);
		
		sendMessage(args[0]);
		
		while(true) {
				String str = sc.nextLine();
				String[] input = str.split("\\s+");
				if (input[0].equals("put")) {
					sendMessage(str);
				} else if (input[0].equals("list")) {
					sendMessage(str);
					String inputFromServer = br.readLine();
					while(!inputFromServer.equals("stop")){
						System.out.println(inputFromServer);
						inputFromServer = br.readLine();
					}
				} else if(input[0].equals("bid")){
					sendMessage(str);
				} else {
					System.out.println("Hibas parancs!");
					continue;
				}
		}
	}
	
	static void sendMessage(String message) {
		pw.println(message);
		pw.flush();
	}
}