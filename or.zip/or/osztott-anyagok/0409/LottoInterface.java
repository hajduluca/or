
import java.rmi.*;

public interface LottoInterface extends Remote
{
    boolean nyeroszamE() throws RemoteException;
}
