import java.net.ServerSocket;
import java.net.Socket;
import java.io.*;
import java.util.*;

public class Tracker {
	private final int SERVER_PORT = 55555;
	private Client client;
	private ServerSocket server;
	//private boolean clientDisconnected = false;
	//public ArrayList<Item> items = new ArrayList<>();
	public Map<String, Integer> nodes = new HashMap<String, Integer>();
	
	public static void main(String[] args) {
		try {
			Tracker tracker = new Tracker();
			tracker.start();
		} catch (IOException e) {
			System.out.println("ez!");
			e.printStackTrace();
		}
	}
	
	private Tracker() throws IOException {
		server = new ServerSocket(SERVER_PORT);
	}
	
	void start() throws IOException {
		//clientDisconnected = false;
		System.out.println("Kliensre varunk!");
		try{
			Socket s = server.accept();
			BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			PrintWriter pw = new PrintWriter(s.getOutputStream());
			
			client = new Client(s, br, pw);	
			
			//String name = client.reader.readLine();
			//client.name = name;
			System.out.println("Egy kliens csatlakozott a trackerre.");
			handleClients();	
		} catch (IOException e) {
			System.out.println("A kliens lecsatlakozott!\n");
			start();
		}	
	}

	private void handleClients() throws IOException {
		System.out.println("Kezdodhet a torrentezes!\n");
		try{
			while(client.isConnected()) {
					String input = client.reader.readLine();
					//String[] input = str.split("\\s+");
					
					switch (input) {
						case "leech":	input = client.reader.readLine();
										client.sendMessage(Integer.toString(lookupPeerPort(input)));
										System.out.println(lookupPeerPort(input));
										break;
										
						case "seed": 	input = client.reader.readLine();
										String[] arguments = input.split("\\s+");
										Integer peerPort = Integer.parseInt(arguments[0]);
										for(int i=1;i<arguments.length;i+=2) {
											storeFileId(arguments[i], peerPort);
										}
										client.close();
										break;
					}
			}
		} catch (IOException e) {
			System.out.println("A kliens lecsatlakozott!\n");
			start();
		}
	}

	class Client {
		public Socket client;
		public BufferedReader reader;
		public PrintWriter writer;
		public String name = "";
		
		Client(Socket s, BufferedReader br, PrintWriter pw) {
			this.client = s;
			this.reader = br;
			this.writer = pw;
		}
		
		boolean isConnected(){
			return this.client.isConnected();
		}
		
		void sendMessage(String message) {
			writer.println(message);
			writer.flush();
		}
		
		void close() {
			try {
				client.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	void storeFileId(String fileId, Integer peerPort){
		nodes.put(fileId, peerPort);
	}
	
	Integer lookupPeerPort(String fileId) {
		try{
			return nodes.get(fileId);
		} catch (Exception e){
			client.sendMessage("A fajl nem talalhato!");
			return 0;
		}
	}
}