import java.net.ServerSocket;
import java.net.Socket;
import java.io.*;
import java.util.*;

public class Election2019 {
	private final int SERVER_PORT = 2019;
	private Client client;
	private ServerSocket server;
	public Map<String, Integer[]> electors = new HashMap<String, Integer[]>();
	public ArrayList<Szavazas> szavazas = new ArrayList<>();
	
	public static void main(String[] args) {
		try {
			Election2019 election = new Election2019();
			election.fileRead();
			election.start();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private Election2019() throws IOException {
		server = new ServerSocket(SERVER_PORT);
	}
	
	void fileRead() throws FileNotFoundException, IOException {
		File file=new File("electors.txt");
		BufferedReader br = new BufferedReader(new FileReader(file));
		String line;
		while((line=br.readLine()) != null){
			String[] inputLine = line.split("\\s+");
			electors.put(inputLine[2], new Integer[] {Integer.parseInt(inputLine[0]), Integer.parseInt(inputLine[1])});
		}
	}
	
	void start() throws IOException {
		System.out.println("Egy allam csatalkozasara varunk!");
		try{
			Socket s = server.accept();
			BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			PrintWriter pw = new PrintWriter(s.getOutputStream());
			
			client = new Client(s, br, pw);	

			startVoting();	
		} catch (IOException e) {
			System.out.println("A kliens lecsatlakozott!\n");
			start();
		}	
	}

	private void startVoting() throws IOException, NullPointerException {
		System.out.println("Kezdodhet a szavazas!\n");
		try{
			while(client.isConnected()) {
					String str = client.reader.readLine();
					String[] input = str.split("\\s+");
					
					if(input[0].equals("A") || input[0].equals("B")) {
						szavazas.add(new Szavazas(input[0], electors.get(input[1])[0], electors.get(input[1])[1]));
						client.sendMessage(getAllapot());
						client.close();
					}
					else if(input[0].equals("end")){
						int szavazatKulonbseg=1000000;
						if(input.length != 1){
							szavazatKulonbseg = Integer.parseInt(input[1]);
						}
						
						int gyoztes=gyoztesKihirdetese(szavazatKulonbseg);
						switch (gyoztes) {
							case 1:		client.sendMessage("A gyozott!");
										client.close();
										break;
											
							case 2: 	client.sendMessage("B gyozott!");
										client.close();
										break;
							case 0: 	client.sendMessage("A valasztast meg kell ismetelni!");
										client.close();
										szavazas.clear();
										this.start();
										break;										
					}
					}
					else{
						System.out.println("Hibas parancs!");
					}
			}
		} catch (IOException e) {
			System.out.println("A kliens lecsatlakozott!\n");
			start();
		} catch (NullPointerException e){
			client.sendMessage("Nem letezik ilyen nevu allam!");
			startVoting();
		}
	}
	
	public int gyoztesKihirdetese(int szavazatKulonbseg){
		int elektorA=0;
		int lakosA=0;
		int elektorB=0;
		int lakosB=0;
		for(int i=0;i<szavazas.size();i++){
			if(szavazas.get(i).jeloltNev.equals("A")){
				elektorA += szavazas.get(i).elektor;
				lakosA += szavazas.get(i).lakos;
			}
			else if(szavazas.get(i).jeloltNev.equals("B")){
				elektorB += szavazas.get(i).elektor;
				lakosB += szavazas.get(i).lakos;
			}
		}
		if(elektorA > elektorB){
			if(szavazatKulonbseg <= lakosB-lakosA){
				return 0;
			}
			else{
				return 1;
			}
		}
		else if(elektorB > elektorA){
			if(szavazatKulonbseg <= lakosA-lakosB){
				return 0;
			}
			else{
				return 2;			
			}
		}
		else{
			return 0;
		}
	}
	
	public String getAllapot() throws NullPointerException{
		try{
			int elektorA=0;
			int lakosA=0;
			int elektorB=0;
			int lakosB=0;
			String allapot="";
			for(int i=0;i<szavazas.size();i++){
				if(szavazas.get(i).jeloltNev.equals("A")){
					elektorA += szavazas.get(i).elektor;
					lakosA += szavazas.get(i).lakos;
				}
				else if(szavazas.get(i).jeloltNev.equals("B")){
					elektorB += szavazas.get(i).elektor;
					lakosB += szavazas.get(i).lakos;
				}
			}
			allapot = "A | elektorok: "+elektorA+" lakosok: "+lakosA+"\r\n"+"B |elektorok: "+elektorB+" lakosok: "+lakosB;
			return allapot;
		}catch(NullPointerException e){
			return "Nincs ilyen allam!";
		}
	}
	

	class Client {
		public Socket client;
		public BufferedReader reader;
		public PrintWriter writer;
		public String name = "";
		
		Client(Socket s, BufferedReader br, PrintWriter pw) {
			this.client = s;
			this.reader = br;
			this.writer = pw;
		}
		
		boolean isConnected(){
			return this.client.isConnected();
		}
		
		void sendMessage(String message) {
			writer.println(message);
			writer.flush();
		}
		
		void close() {
			try {
				client.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	class Szavazas{
		public String jeloltNev;
		public int elektor;
		public int lakos;
		
		Szavazas(String jeloltNev, int elektor, int lakos){
			this.jeloltNev=jeloltNev;
			this.elektor=elektor;
			this.lakos=lakos;
		}		
	}
}