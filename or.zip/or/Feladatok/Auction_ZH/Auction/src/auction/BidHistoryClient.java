package auction;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;
import java.util.Scanner;

public class BidHistoryClient {
    
    public static void main(String[] args) {
        try {
            int port = 31138;
            String name = "history";
            Registry registry = LocateRegistry.getRegistry(port);
            BidHistory comp = (BidHistory) registry.lookup(name);
            Scanner sc = new Scanner(System.in);
            String line;
            System.out.println("bidhistory - or - change");
            while(sc.hasNextLine()) {
                line = sc.nextLine();
                String[] str = line.split(" ");
                switch(str[0]) {
                    case "bidhistory":
                        ArrayList<String> result = comp.bidhistory();
                        for(String x : result) {
                            //System.out.println(x.getDate() + " " + x.getIthemName() + " " + x.getIthemValue() + " " + x.getWinner());
                            System.out.println(x);
                        }
                        break;
                    case "change":
                        comp.openOrClose();
                        break;
                   
                }
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
