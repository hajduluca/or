package auction;

import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class BidHistoryImp implements BidHistory{
    
    public ArrayList<Ithem> bidHistory;
    public boolean close;

    public BidHistoryImp(ArrayList<Ithem> bidHistory, boolean close) {
        this.bidHistory = bidHistory;
        this.close = close;
    }
    
    @Override
    public ArrayList<String> bidhistory() throws RemoteException {
        ArrayList<String> result = new ArrayList<>();
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        for(Ithem x : bidHistory) {
            if( !(x.getIthemValue() == 0) ) {
                x.setDate(sdf);
                //result.add(x.getIthemName());
                String data = x.getDate() + " " + x.getIthemName() + " " + x.getIthemValue() + " " + x.getWinner();
                result.add(data);
            }
        }
        return result;
    }

    @Override
    public void openOrClose() throws RemoteException {
        close = !close;
    }
    
    
    
}
