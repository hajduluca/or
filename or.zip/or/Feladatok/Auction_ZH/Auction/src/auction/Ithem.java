package auction;

import java.text.SimpleDateFormat;

public class Ithem {
    
    private String ithemName;
    private int ithemValue;
    private String winner;
    public SimpleDateFormat date;

    public Ithem(String ithemName) {
        this.ithemName = ithemName;
        this.ithemValue = 0;
        this.winner = "";
    }

    public void setDate(SimpleDateFormat date) {
        this.date = date;
    }

    public SimpleDateFormat getDate() {
        return date;
    }

    public String getIthemName() {
        return ithemName;
    }

    public int getIthemValue() {
        return ithemValue;
    }

    public void setIthemName(String ithemName) {
        this.ithemName = ithemName;
    }

    public void setIthemValue(int ithemValue) {
        this.ithemValue = ithemValue;
    }

    public String getWinner() {
        return winner;
    }

    public void setWinner(String winner) {
        this.winner = winner;
    }
    
    
    
    
    
}
