package auction;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;

public interface BidHistory extends Remote  {
    
    public ArrayList<String> bidhistory() throws RemoteException;
    public void openOrClose() throws RemoteException;
    
    
    
}
