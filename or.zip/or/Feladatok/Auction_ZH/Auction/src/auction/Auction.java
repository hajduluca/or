package auction;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Scanner;

public class Auction {
    
    static boolean close = true;
    
    public static void main(String[] args) throws InterruptedException, IOException {
            Accepter server = new Accepter();
            if(close) {
                server.start();
            }else {
                System.out.println("Zarva!");
            }

            System.out.println("Wait for RMI");
            int PORT = 31138;
            java.rmi.registry.LocateRegistry.createRegistry(PORT);
            try {

                String name = "history";
                BidHistory engine = new BidHistoryImp(server.ithems, close);
                BidHistory stub =
                        (BidHistory) UnicastRemoteObject.exportObject(engine, 0);
                Registry registry = LocateRegistry.getRegistry(PORT);
                registry.rebind(name, stub);
                System.out.println("Szolgaltatas bound");
            } catch (Exception e) {
                System.err.println("Szolgaltatas exception:");
                e.printStackTrace();
            }
            
    }
}

class Accepter extends Thread {

    public ServerSocket serverSocket;
    public ArrayList<Client> clients;
    public ArrayList<Ithem> ithems;
    
    public Accepter() throws IOException {
        this.serverSocket = new ServerSocket(2121);
        this.clients = new ArrayList<>();
        this.ithems = new ArrayList<>();
    }

    @Override
    public void run() {
        System.out.println("Starting accepter");
        while (true) {
            try {
                Socket s = serverSocket.accept();
                Client client = new Client(s, clients, ithems);
                client.start();
                synchronized (clients) {
                    clients.add(client);
                }
                System.out.println(s.getRemoteSocketAddress());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}

class Client extends Thread {

    private Socket s;
    private ArrayList<Client> clients;
    private String name;
    private ArrayList<Ithem> ithems;
    private Scanner in;
    private PrintWriter out;

    public Client(Socket socket, ArrayList<Client> clients, ArrayList<Ithem> ithems) throws IOException {
        this.s = socket;
        this.clients = clients;
        this.name = "";
        this.ithems = ithems;
        this.in = new Scanner(socket.getInputStream());
        this.out = new PrintWriter(socket.getOutputStream());
    }

    @Override
    public void run() {
        try {
            out.println("Eloszor add meg a neved!");
            out.flush();
            while (in.hasNextLine()) {
                String[] cmd = in.nextLine().split(" ");
                if(cmd.length == 1 && !cmd[0].equals("list")) {
                    name = cmd[0];
                    out.println("OK");
                    out.flush();
                    System.out.println("Name: " + name);
                }else {
                    switch(cmd[0]) {
                        case "put":
                            String ithemString = cmd[1];
                            System.out.println(ithemString);
                            Ithem ithem = new Ithem(ithemString);
                            synchronized(ithems) {
                                ithems.add(ithem);
                                System.out.println("sync put");
                            }
                            System.out.println("PUT");
                            break;
                        case "list":
                            ArrayList<Ithem> pufferIthem;
                            synchronized(ithems) {
                                pufferIthem = ithems;
                                System.out.println("sync list");
                            }
                            out.println(pufferIthem.size());
                            for(Ithem x : pufferIthem) {
                                out.println(x.getIthemName() + " " + x.getIthemValue() + " "+ x.getWinner());
                                out.flush();
                            }
                            System.out.println("LIST");
                            break;
                        case "bid":
                            String ithemLicitName = cmd[1];
                            ArrayList<Ithem> ithemsForLicit;
                            synchronized(ithems) {
                                ithemsForLicit = ithems;
                                System.out.println("sync bid");
                            }
                            for(Ithem x : ithemsForLicit) {
                                if(x.getIthemName().equals(ithemLicitName)) {
                                    x.setIthemValue(x.getIthemValue() + 1);
                                    x.setWinner(name);
                                }
                            }
                            System.out.println("BID");
                            break;
                        default:
                            System.out.println("Unknown command");
                            break;
                    }
                }
            }
        System.out.println("Client disconnected");
        try {
            close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void close() throws Exception {
        out.close();
        in.close();
        s.close();
    }
    
}