import java.net.ServerSocket;
import java.net.Socket;
import java.io.*;
import java.util.*;

public class Blackjack {
	private final int SERVER_PORT = 2121;
	private Client client1;
	private Client client2;
	private ServerSocket server;
	private boolean gameIsOver = false;
	Random rand = new Random();
	
	public static void main(String[] args) {
		try {
			Blackjack game = new Blackjack();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private Blackjack() throws IOException {
		server = new ServerSocket(SERVER_PORT);
		newGame();
	}
	private void newGame() throws IOException {
		gameIsOver = false;
		System.out.println("Jatekosokra varunk!");
		Socket s1 = server.accept();
		BufferedReader br1 = new BufferedReader(new InputStreamReader(s1.getInputStream()));
		PrintWriter pw1 = new PrintWriter(s1.getOutputStream());
		
		client1 = new Client(s1, br1, pw1);	
		
		String name1 = client1.reader.readLine();
		client1.name = name1;
		System.out.println(name1 + " megerkezett");
		
		Socket s2 = server.accept();
		BufferedReader br2 = new BufferedReader(new InputStreamReader(s2.getInputStream()));
		PrintWriter pw2 = new PrintWriter(s2.getOutputStream());
		
		client2 = new Client(s2, br2, pw2);
		
		String name2 = client2.reader.readLine();
		client2.name = name2;
		System.out.println(name2 + " megerkezett");
		
		runGame();		
	}
	
	private int drawNumber() {
		return rand.nextInt(9) + 2;
	}
	
	private void startGame() throws IOException {
		int szam1 = drawNumber();
		client1.addNumber(szam1);

		int szam2 = drawNumber();
		client1.addNumber(szam2);

		int szam3 = drawNumber();
		client2.addNumber(szam3);

		int szam4 = drawNumber();
		client2.addNumber(szam4);
	}

	private void runGame() throws IOException {
		System.out.println("Kezdodhet a jatek!\n");
		startGame();
		while(!gameIsOver) {
			if (!client1.bust && !client1.stick) {
				String input1 = client1.reader.readLine();
				switch (input1) {
					case "hit":   	client1.addNumber(drawNumber()); 
									break;
					case "stick": 	client1.stick = true; 
									System.out.println(client1.name + " stick");
									break;
				}	
			}
			if (!client2.bust && !client2.stick) {
				String input2 = client2.reader.readLine();
				switch (input2) {
					case "hit":   	client2.addNumber(drawNumber()); 
									break;
					case "stick": 	client2.stick = true;
									System.out.println(client2.name + " stick");
									break;
				}
			}
			if ((client1.bust || client1.stick) && (client2.bust || client2.stick)) {
				gameIsOver = true;
				String winner = "";
				if (client2.bust) {
					winner = client1.name;
				} else if (client1.bust) {
					winner = client2.name;
				}
				else {
					int client1DistanceFrom21 = 21 - client1.sumOfCards;
					int client2DistanceFrom21 = 21 - client2.sumOfCards;
					if (client1DistanceFrom21 <= client2DistanceFrom21) {
						winner = client1.name;
					} else {
						winner = client2.name;
					}
				}
				announceWinner(winner);
				client1.close();
				client2.close();
			}
		}
		System.out.println("A jatek veget ert!\n");
		newGame();
	}
	
	private void announceWinner(String name) {
		String message = "Nyertes: " + name;
		System.out.println(message);
		client1.sendMessage(message);
		client2.sendMessage(message);		
	}
	
	class Client {
		public Socket client;
		public BufferedReader reader;
		public PrintWriter writer;
		public String name = "";
		public ArrayList<Integer> cards = new ArrayList<>();
		public boolean bust = false;
		public boolean stick = false;
		public int sumOfCards = 0;
		
		Client(Socket s, BufferedReader br, PrintWriter pw) {
			this.client = s;
			this.reader = br;
			this.writer = pw;
		}
		
		void addNumber(int number) {
			cards.add(number);
			sumOfCards += number;
			System.out.println(name + " huzasa: " + number
			+ "\n " + name + " lapjainak osszege: " + sumOfCards);
			
			sendMessage("" + number);
			
			String message = sumOfCards <=21 ? "" + sumOfCards : "bust";
			if (message.equals("bust"))
				bust = true;
			sendMessage(message);
		}	
		
		void sendMessage(String message) {
			writer.println(message);
			writer.flush();
		}
		
		void close() {
			try {
				client.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}