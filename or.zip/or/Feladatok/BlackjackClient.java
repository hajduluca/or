import java.io.*;
import java.util.*;
import java.net.Socket;

public class BlackjackClient {
	
	private static final int SERVER_PORT = 2121;
	private static Socket server;
	private static BufferedReader br;
	private static PrintWriter pw;
	private static boolean stick = false;
	private static boolean bust = false;
	private static Scanner sc;
	private static boolean gameIsOver = false;

	public static void main(String[] args) throws IOException {
		if (args.length != 1) {
			System.out.println("Kotelezo a nev megadasa!");
			System.exit(0);
		}
		server = new Socket("localhost", SERVER_PORT);
		br = new BufferedReader(new InputStreamReader(server.getInputStream()));
		pw = new PrintWriter(server.getOutputStream());
		sc = new Scanner(System.in);
		
		sendMessage(args[0]);
		
		//Első szám felhúzása, kiírása
		String num1 = br.readLine();
		System.out.println(num1);
		String sum1 = br.readLine();
		System.out.println("Ossz: " + sum1);
		
		//Második szám felhúzása, kiírása
		String num2 = br.readLine();
		System.out.println(num2);
		String sum2 = br.readLine();
		System.out.println("Ossz: " + sum2);
		
		while(!gameIsOver) {
			if (bust || stick) {
				String line = br.readLine();
				if (line == null) {
					gameIsOver = true;
				} else {
					System.out.println(line);
				}
			} else {
				String input = sc.nextLine();
				if (input.equals("stick")) {
					stick = true;
					sendMessage("stick");
				} else if (input.equals("hit")) {
					sendMessage("hit");
					String inputFromServer = br.readLine();
					System.out.println(inputFromServer);
					inputFromServer = br.readLine();
					if (inputFromServer.equals("bust")) {
						bust = true;
						System.out.println("bust");
					} else {
						System.out.println("Ossz: " + inputFromServer);
					}
				} else {
					System.out.println("Hibas uzenet! stick vagy hit uzenetet kell kuldeni!");
					continue;
				}
			}
		}
		System.out.println("A jatek veget ert.");
		System.exit(0);
	}
	
	static void sendMessage(String message) {
		pw.println(message);
		pw.flush();
	}
}