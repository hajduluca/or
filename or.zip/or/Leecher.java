import java.io.*;
import java.util.*;
import java.net.Socket;

public class Leecher {
	
	private static final int SERVER_PORT = 55555;
	private static Socket server;
	private static BufferedReader br;
	private static PrintWriter pw;
	private static Scanner sc;

	public static void main(String[] args) throws IOException {
		if (args.length != 1) {
			System.out.println("Add meg a fajlt!");
			System.exit(0);
		}
		server = new Socket("localhost", SERVER_PORT);
		br = new BufferedReader(new InputStreamReader(server.getInputStream()));
		pw = new PrintWriter(server.getOutputStream());
		sc = new Scanner(System.in);
		
		sendMessage("leech");
		sendMessage(args[0]);
		
		String inputFromServer = br.readLine();
		Integer peerPort = Integer.parseInt(inputFromServer);
		
		server = new Socket("localhost", peerPort);
		br = new BufferedReader(new InputStreamReader(server.getInputStream()));
		pw = new PrintWriter(server.getOutputStream());
		sc = new Scanner(System.in);
		
		sendMessage(args[0]);
		
		inputFromServer = br.readLine();
		System.out.println("Fajl tartalma: "+inputFromServer);
		
	}
	
	static void sendMessage(String message) {
		pw.println(message);
		pw.flush();
	}
}